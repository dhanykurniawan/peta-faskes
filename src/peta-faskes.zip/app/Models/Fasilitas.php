<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Kecamatan;
use App\Models\KabupatenKota;
use App\Models\Layanan;

class Fasilitas extends Model
{
    protected $fillable = ['nama', 'tipe', 'tipe_detail', 'kelas', 'kecamatan_id', 'kabkota_id', 'alamat', 'lat', 'lng', 'telepon', 'email', 'website', 'status_aktif'];

    protected $casts = [
        'status_aktif' => 'boolean',
        'lat' => 'float',
        'lng' => 'float',
    ];

    public function kecamatan()
    {
        return $this->belongsTo(Kecamatan::class);
    }

    public function kabupatenKota()
    {
        return $this->belongsTo(KabupatenKota::class, 'kabkota_id');
    }

    public function layanans()
    {
        return $this->belongsToMany(Layanan::class, 'fasilitas_layanan');
    }
}
