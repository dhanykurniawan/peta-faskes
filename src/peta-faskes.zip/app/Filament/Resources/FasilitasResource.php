<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FasilitasResource\Pages;
use App\Filament\Resources\FasilitasResource\RelationManagers;
use App\Models\Fasilitas;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

use App\Models\Kecamatan;
use Filament\Tables\Columns\TextColumn;

class FasilitasResource extends Resource
{
    protected static ?int $navigationSort = 2;
    protected static ?string $navigationLabel = 'Fasilitas Kesehatan'; // -> nama di sidebar
    protected static ?string $pluralModelLabel = 'Fasilitas Kesehatan'; // -> nama singular (muncul di tombol "Buat ...")
    protected static ?string $modelLabel = 'Fasilitas Kesehatan'; // -> nama plural (muncul di judul halaman list)

    protected static ?string $model = Fasilitas::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Section::make('Informasi Dasar')
                ->schema([
                    Forms\Components\TextInput::make('nama')->required(),
                    Forms\Components\Select::make('tipe')
                        ->options(['FKTP' => 'FKTP', 'FKRTL' => 'FKRTL'])
                        ->required()
                        ->reactive(),
                    Forms\Components\Select::make('tipe_detail')->options(
                        fn(callable $get) => match ($get('tipe')) {
                            'FKTP' => ['Puskesmas' => 'Puskesmas', 'Klinik Pratama' => 'Klinik Pratama', 'Dokter Praktek' => 'Dokter Praktek'],
                            'FKRTL' => ['RS Umum' => 'RS Umum', 'RS Khusus' => 'RS Khusus', 'Klinik Utama' => 'Klinik Utama'],
                            default => [],
                        },
                    ),
                    Forms\Components\TextInput::make('kelas')->label('Kelas'),
                    Forms\Components\Toggle::make('status_aktif')->default(true),
                ])
                ->columns(2),

            Forms\Components\Section::make('Wilayah')
                ->schema([
                    Forms\Components\Select::make('kabkota_id')->label('Kabupaten/Kota')->relationship('kabupatenKota', 'nama')->searchable()->required()->reactive()->preload(), 
                    Forms\Components\Select::make('kecamatan_id')->label('Kecamatan')->options(fn(callable $get) => \App\Models\Kecamatan::where('kabkota_id', $get('kabkota_id'))->pluck('nama', 'id'))->searchable()->preload()->required()
                ])
                ->columns(2),

            Forms\Components\Section::make('Kontak & Lokasi')
                ->schema([
                    Forms\Components\TextInput::make('alamat'), 
                    Forms\Components\TextInput::make('telepon'), Forms\Components\TextInput::make('email')->email(), Forms\Components\TextInput::make('website')->url(), Forms\Components\TextInput::make('lat')->label('Latitude')->numeric(), Forms\Components\TextInput::make('lng')->label('Longitude')->numeric()])
                ->columns(2),

            Forms\Components\Section::make('Layanan')->schema([Forms\Components\CheckboxList::make('layanans')->relationship('layanans', 'nama_layanan')->columns(3)]),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('no')->label('No.')->rowIndex()->alignCenter(),
                Tables\Columns\TextColumn::make('nama')->searchable()->sortable(), 
                Tables\Columns\BadgeColumn::make('tipe')->colors(['primary' => 'FKTP', 'danger' => 'FKRTL'])->alignCenter(),
                Tables\Columns\TextColumn::make('tipe_detail')->alignCenter(),
                Tables\Columns\TextColumn::make('kelas')->alignCenter(),
                Tables\Columns\TextColumn::make('kabupatenKota.nama')->label('Kab/Kota')->sortable(), 
                Tables\Columns\TextColumn::make('kecamatan.nama')->label('Kecamatan')->sortable(), 
                Tables\Columns\IconColumn::make('status_aktif')->boolean()->alignCenter(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('tipe')->options(['FKTP' => 'FKTP', 'FKRTL' => 'FKRTL']), 
                Tables\Filters\SelectFilter::make('kabkota_id')->label('Kabupaten/Kota')->relationship('kabupatenKota', 'nama')
            ])
            ->actions([Tables\Actions\EditAction::make(), Tables\Actions\DeleteAction::make()]);
    }

    public static function getRelations(): array
    {
        return [
                //
            ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListFasilitas::route('/'),
            'create' => Pages\CreateFasilitas::route('/create'),
            'edit' => Pages\EditFasilitas::route('/{record}/edit'),
        ];
    }
}
