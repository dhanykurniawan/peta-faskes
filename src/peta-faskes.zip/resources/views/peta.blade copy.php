<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peta Faskes BPJS KC Bukittinggi</title>

    {{-- Leaflet CSS --}}
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f4f8;
            display: flex;
            height: 100vh;
        }

        /* ── Sidebar ── */
        #sidebar {
            width: 320px;
            background: #fff;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            z-index: 1000;
        }

        #sidebar-header {
            background: #00529B;
            color: white;
            padding: 16px;
        }

        #sidebar-header h1 {
            font-size: 14px;
            font-weight: 600;
        }

        #sidebar-header p {
            font-size: 11px;
            opacity: 0.8;
            margin-top: 4px;
        }

        #sidebar-content {
            flex: 1;
            overflow-y: auto;
            padding: 16px;
        }

        #sidebar-content h2 {
            font-size: 13px;
            color: #666;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Kartu kab/kota */
        .kabkota-card {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .kabkota-card:hover {
            border-color: #00529B;
            background: #f0f7ff;
        }

        .kabkota-card.active {
            border-color: #00529B;
            background: #e8f2ff;
        }

        .kabkota-card h3 {
            font-size: 13px;
            font-weight: 600;
            color: #1a202c;
        }

        .kabkota-badge {
            display: flex;
            gap: 8px;
            margin-top: 6px;
        }

        .badge {
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 99px;
            font-weight: 500;
        }

        .badge-fktp {
            background: #dcfce7;
            color: #166534;
        }

        .badge-fkrtl {
            background: #fee2e2;
            color: #991b1b;
        }

        /* Panel detail */
        #detail-panel {
            display: none;
        }

        .detail-title {
            font-size: 14px;
            font-weight: 700;
            color: #00529B;
            margin-bottom: 4px;
        }

        .back-btn {
            font-size: 12px;
            color: #00529B;
            cursor: pointer;
            margin-bottom: 12px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .back-btn:hover {
            text-decoration: underline;
        }

        .faskes-item {
            border-left: 3px solid #e2e8f0;
            padding: 8px 10px;
            margin-bottom: 6px;
            border-radius: 0 6px 6px 0;
        }

        .faskes-item.fkrtl {
            border-color: #ef4444;
        }

        .faskes-item.fktp {
            border-color: #22c55e;
        }

        .faskes-item h4 {
            font-size: 12px;
            font-weight: 600;
        }

        .faskes-item p {
            font-size: 11px;
            color: #666;
            margin-top: 2px;
        }

        /* ── Map ── */
        #map {
            flex: 1;
            z-index: 1;
        }

        /* Loading */
        #loading {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 16px 24px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            z-index: 9999;
            font-size: 13px;
            color: #333;
        }

        /* Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .modal-overlay.active {
            display: flex;
        }

        .modal-box {
            background: white;
            border-radius: 12px;
            width: 420px;
            max-width: 90vw;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            background: #00529B;
            color: white;
            padding: 16px 20px;
            border-radius: 12px 12px 0 0;
            position: sticky;
            top: 0;
        }

        .modal-header h3 {
            font-size: 15px;
            font-weight: 700;
        }

        .modal-header p {
            font-size: 11px;
            opacity: 0.8;
            margin-top: 4px;
        }

        .modal-close {
            position: absolute;
            top: 14px;
            right: 16px;
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            line-height: 1;
        }

        .modal-body {
            padding: 16px 20px;
        }

        .modal-row {
            display: flex;
            gap: 8px;
            margin-bottom: 10px;
            align-items: flex-start;
        }

        .modal-label {
            font-size: 11px;
            color: #666;
            min-width: 90px;
            padding-top: 2px;
        }

        .modal-value {
            font-size: 13px;
            color: #1a202c;
            font-weight: 500;
            flex: 1;
        }

        .layanan-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            margin-top: 10px;
        }

        .layanan-tag {
            background: #e0f2fe;
            color: #0369a1;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 99px;
        }

        .divider {
            border: none;
            border-top: 1px solid #e2e8f0;
            margin: 12px 0;
        }
    </style>
</head>

<body>

    {{-- Sidebar --}}
    <div id="sidebar">
        <div id="sidebar-header">
            <h1>🏥 Peta Faskes BPJS</h1>
            <p>KC Bukittinggi — 5 Kab/Kota</p>
        </div>
        <div id="sidebar-content">
            {{-- Panel list kab/kota --}}
            <div id="list-panel">
                <h2>Pilih Wilayah</h2>
                <div id="kabkota-list">Memuat...</div>
            </div>

            {{-- Panel detail kab/kota --}}
            <div id="detail-panel">
                <span class="back-btn" onclick="backToList()">← Kembali</span>
                <div class="detail-title" id="detail-title"></div>
                <p style="font-size:11px; color:#666; margin-bottom:12px">
                    Klik kecamatan di peta untuk melihat faskes
                </p>
                <div id="fkrtl-list"></div>
            </div>

            {{-- Panel kecamatan --}}
            <div id="kecamatan-panel" style="display:none">
                <span class="back-btn" onclick="backToKabkota()">← Kembali</span>
                <div class="detail-title" id="kecamatan-title"></div>
                <div id="kecamatan-faskes"></div>
            </div>
        </div>
    </div>

    {{-- Map --}}
    <div id="map"></div>
    <div id="loading">Memuat peta...</div>

    {{-- Modal --}}
    <div class="modal-overlay" id="modalOverlay" onclick="closeModal(event)">
        <div class="modal-box">
            <div class="modal-header" style="position:relative">
                <h3 id="modal-nama"></h3>
                <p id="modal-subtitle"></p>
                <button class="modal-close" onclick="closeModalDirect()">×</button>
            </div>
            <div class="modal-body">
                <div class="modal-row">
                    <span class="modal-label">Tipe</span>
                    <span class="modal-value" id="modal-tipe"></span>
                </div>
                <div class="modal-row">
                    <span class="modal-label">Jenis</span>
                    <span class="modal-value" id="modal-tipe-detail"></span>
                </div>
                <div class="modal-row">
                    <span class="modal-label">Kelas</span>
                    <span class="modal-value" id="modal-kelas"></span>
                </div>
                <div class="modal-row">
                    <span class="modal-label">Status</span>
                    <span class="modal-value" id="modal-status"></span>
                </div>
                <hr class="divider">
                <div class="modal-row">
                    <span class="modal-label">Alamat</span>
                    <span class="modal-value" id="modal-alamat"></span>
                </div>
                <div class="modal-row">
                    <span class="modal-label">Telepon</span>
                    <span class="modal-value" id="modal-telepon"></span>
                </div>
                <div class="modal-row">
                    <span class="modal-label">Email</span>
                    <span class="modal-value" id="modal-email"></span>
                </div>
                <div class="modal-row">
                    <span class="modal-label">Website</span>
                    <span class="modal-value" id="modal-website"></span>
                </div>
                <hr class="divider" id="divider-layanan" style="display:none">
                <div id="modal-layanan-wrap" style="display:none">
                    <p style="font-size:11px;color:#666;margin-bottom:6px">Layanan Tersedia</p>
                    <div class="layanan-tags" id="modal-layanan"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- Leaflet JS --}}
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <script>
        // ── Init Map ──
        const map = L.map('map').setView([-0.3, 100.1], 9);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        // ── State ──
        let kabkotaLayer = null;
        let kecamatanLayer = null;
        let activeKabkotaId = null;
        let kabkotaData = [];

        // ── Style ──
        const styleDefault = {
            color: '#00529B',
            weight: 2,
            fillColor: '#3b82f6',
            fillOpacity: 0.15,
        };

        const styleHover = {
            fillOpacity: 0.35,
            weight: 3,
        };

        const styleKecamatan = {
            color: '#7c3aed',
            weight: 1.5,
            fillColor: '#8b5cf6',
            fillOpacity: 0.15,
        };

        const styleKecamatanHover = {
            fillOpacity: 0.4,
            weight: 2.5,
        };

        // ── Load GeoJSON Kab/Kota ──
        fetch('/geojson/wilayah.geojson')
            .then(r => r.json())
            .then(geojson => {
                document.getElementById('loading').style.display = 'none';

                kabkotaLayer = L.geoJSON(geojson, {
                    style: styleDefault,
                    onEachFeature: (feature, layer) => {
                        const label = feature.properties.label;
                        layer.bindTooltip(label, {
                            sticky: true
                        });

                        layer.on({
                            mouseover: e => e.target.setStyle(styleHover),
                            mouseout: e => kabkotaLayer.resetStyle(e.target),
                            click: e => onKabkotaClick(feature, layer),
                        });
                    }
                }).addTo(map);

                map.fitBounds(kabkotaLayer.getBounds());
            });

        // ── Load Data Kabkota (sidebar) ──
        fetch('/api/kabkota')
            .then(r => r.json())
            .then(data => {
                kabkotaData = data;
                const container = document.getElementById('kabkota-list');
                container.innerHTML = '';

                data.forEach(item => {
                    const card = document.createElement('div');
                    card.className = 'kabkota-card';
                    card.dataset.id = item.id;
                    card.innerHTML = `
                    <h3>${item.nama}</h3>
                    <div class="kabkota-badge">
                        <span class="badge badge-fktp">FKTP: ${item.fktp_count}</span>
                        <span class="badge badge-fkrtl">FKRTL: ${item.fkrtl_count}</span>
                    </div>
                `;
                    card.addEventListener('click', () => {
                        // Zoom ke wilayah di peta
                        zoomToKabkota(item.nama);
                    });
                    container.appendChild(card);
                });
            });

        // ── Klik Kab/Kota di Peta ──
        function onKabkotaClick(feature, layer) {
            const label = feature.properties.label;
            const slug = feature.properties.slug;

            console.log('Klik:', label, '| slug:', slug); // debug

            const kabkota = kabkotaData.find(k =>
                k.nama.toLowerCase().replace('kabupaten ', '').replace('kota ', '') ===
                feature.properties.NAME_2.replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase()
            );

            console.log('Kabkota match:', kabkota); // debug

            map.fitBounds(layer.getBounds(), {
                padding: [40, 40]
            });

            if (kecamatanLayer) {
                map.removeLayer(kecamatanLayer);
            }

            const url = `/geojson/kecamatan/${slug}.geojson`;
            console.log('Fetch GeoJSON:', url); // debug

            fetch(url)
                .then(r => {
                    if (!r.ok) throw new Error(`HTTP ${r.status}`);
                    return r.json();
                })
                .then(geojson => {
                    console.log('GeoJSON kecamatan loaded:', geojson.features.length, 'features');
                    kecamatanLayer = L.geoJSON(geojson, {
                        style: styleKecamatan,
                        onEachFeature: (feat, lyr) => {
                            lyr.bindTooltip(feat.properties.label, {
                                sticky: true
                            });
                            lyr.on({
                                mouseover: e => e.target.setStyle(styleKecamatanHover),
                                mouseout: e => kecamatanLayer.resetStyle(e.target),
                                click: e => onKecamatanClick(feat, lyr),
                            });
                        }
                    }).addTo(map);
                })
                .catch(err => console.error('Error load kecamatan:', err));

            showDetailPanel(label, kabkota?.id);
        }

        // ── Klik Kecamatan ──
        function onKecamatanClick(feature, layer) {
            const namaKecamatan = feature.properties.label;
            const kabkotaId = activeKabkotaId;

            map.fitBounds(layer.getBounds(), {
                padding: [20, 20]
            });
            showKecamatanPanel(namaKecamatan, kabkotaId);
        }

        // ── Sidebar Functions ──
        function showDetailPanel(namaKabkota, kabkotaId) {
            activeKabkotaId = kabkotaId;
            document.getElementById('list-panel').style.display = 'none';
            document.getElementById('detail-panel').style.display = 'block';
            document.getElementById('kecamatan-panel').style.display = 'none';
            document.getElementById('detail-title').textContent = namaKabkota;

            if (!kabkotaId) return;

            fetch(`/api/kabkota/${kabkotaId}/faskes`)
                .then(r => r.json())
                .then(data => {
                    const container = document.getElementById('fkrtl-list');
                    if (data.length === 0) {
                        container.innerHTML = '<p style="font-size:12px;color:#999">Belum ada data FKRTL</p>';
                        return;
                    }
                    container.innerHTML = `<h2 style="margin-bottom:8px">FKRTL (${data.length})</h2>`;
                    data.forEach(f => {
                        container.innerHTML += `
                    <div class="faskes-item fkrtl" onclick='openModal(${JSON.stringify(f)})' style="cursor:pointer">
                        <h4>${f.nama}</h4>
                        <p>${f.tipe_detail ?? ''} ${f.kelas ? '· ' + f.kelas : ''}</p>
                    </div>
                `;
                    });
                });
        }

        function showKecamatanPanel(namaKecamatan, kabkotaId) {
            document.getElementById('list-panel').style.display = 'none';
            document.getElementById('detail-panel').style.display = 'none';
            document.getElementById('kecamatan-panel').style.display = 'block';
            document.getElementById('kecamatan-title').textContent = namaKecamatan;
            document.getElementById('kecamatan-faskes').innerHTML = '<p style="font-size:12px;color:#999">Memuat...</p>';

            fetch(`/api/kecamatan/cari?nama=${encodeURIComponent(namaKecamatan)}&kabkota_id=${kabkotaId}`)
                .then(r => r.json())
                .then(data => {
                    let html = '';
                    const fktp = data.fktp ?? [];
                    const fkrtl = data.fkrtl ?? [];

                    if (fktp.length === 0 && fkrtl.length === 0) {
                        html = '<p style="font-size:12px;color:#999">Belum ada data faskes di kecamatan ini</p>';
                    }

                    if (fktp.length > 0) {
                        html += `<h2 style="font-size:12px;color:#166534;margin-bottom:6px">FKTP (${fktp.length})</h2>`;
                        fktp.forEach(f => {
                            html += `
                        <div class="faskes-item fktp" onclick='openModal(${JSON.stringify(f)})' style="cursor:pointer">
                            <h4>${f.nama}</h4>
                            <p>${f.tipe_detail ?? ''} ${f.kelas ? '· ' + f.kelas : ''}</p>
                        </div>
                    `;
                        });
                    }

                    if (fkrtl.length > 0) {
                        html +=
                            `<h2 style="font-size:12px;color:#991b1b;margin:10px 0 6px">FKRTL (${fkrtl.length})</h2>`;
                        fkrtl.forEach(f => {
                            html += `
                        <div class="faskes-item fkrtl" onclick='openModal(${JSON.stringify(f)})' style="cursor:pointer">
                            <h4>${f.nama}</h4>
                            <p>${f.tipe_detail ?? ''} ${f.kelas ? '· ' + f.kelas : ''}</p>
                        </div>
                    `;
                        });
                    }

                    document.getElementById('kecamatan-faskes').innerHTML = html;
                })
                .catch(() => {
                    document.getElementById('kecamatan-faskes').innerHTML =
                        '<p style="font-size:12px;color:#999">Kecamatan belum ada di database</p>';
                });
        }

        function backToList() {
            document.getElementById('list-panel').style.display = 'block';
            document.getElementById('detail-panel').style.display = 'none';
            document.getElementById('kecamatan-panel').style.display = 'none';
            if (kecamatanLayer) {
                map.removeLayer(kecamatanLayer);
            }
            map.fitBounds(kabkotaLayer.getBounds());
        }

        function backToKabkota() {
            document.getElementById('list-panel').style.display = 'none';
            document.getElementById('detail-panel').style.display = 'block';
            document.getElementById('kecamatan-panel').style.display = 'none';
        }

        function zoomToKabkota(nama) {
            if (!kabkotaLayer) return;
            kabkotaLayer.eachLayer(layer => {
                const label = layer.feature.properties.label;
                if (label.toLowerCase().includes(nama.toLowerCase().replace('kabupaten ', '').replace('kota ',
                        ''))) {
                    map.fitBounds(layer.getBounds(), {
                        padding: [40, 40]
                    });
                    onKabkotaClick(layer.feature, layer);
                }
            });
        }

        // ── Modal Functions ──
        function openModal(faskes) {
            document.getElementById('modal-nama').textContent = faskes.nama;
            document.getElementById('modal-subtitle').textContent =
                (faskes.kecamatan?.nama ?? '') + ' · ' + (faskes.kabupaten_kota?.nama ?? '');

            document.getElementById('modal-tipe').innerHTML =
                `<span class="badge ${faskes.tipe === 'FKTP' ? 'badge-fktp' : 'badge-fkrtl'}">${faskes.tipe}</span>`;

            document.getElementById('modal-tipe-detail').textContent = faskes.tipe_detail ?? '-';
            document.getElementById('modal-kelas').textContent = faskes.kelas ?? '-';
            document.getElementById('modal-status').textContent = faskes.status_aktif ? '✅ Aktif' : '❌ Tidak Aktif';
            document.getElementById('modal-alamat').textContent = faskes.alamat ?? '-';
            document.getElementById('modal-telepon').textContent = faskes.telepon ?? '-';
            document.getElementById('modal-email').textContent = faskes.email ?? '-';
            document.getElementById('modal-website').textContent = faskes.website ?? '-';

            // Layanan
            const layananWrap = document.getElementById('modal-layanan-wrap');
            const dividerLayanan = document.getElementById('divider-layanan');
            const layananContainer = document.getElementById('modal-layanan');

            if (faskes.layanans && faskes.layanans.length > 0) {
                layananWrap.style.display = 'block';
                dividerLayanan.style.display = 'block';
                layananContainer.innerHTML = faskes.layanans
                    .map(l => `<span class="layanan-tag">${l.nama_layanan}</span>`)
                    .join('');
            } else {
                layananWrap.style.display = 'none';
                dividerLayanan.style.display = 'none';
            }

            document.getElementById('modalOverlay').classList.add('active');
        }

        function closeModal(event) {
            if (event.target === document.getElementById('modalOverlay')) {
                document.getElementById('modalOverlay').classList.remove('active');
            }
        }

        function closeModalDirect() {
            document.getElementById('modalOverlay').classList.remove('active');
        }
    </script>
</body>

</html>
